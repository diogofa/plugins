<div class="wrap">
    <h1>SAZ Tags Plugin Settings</h1>
    <form method="post" action="options.php">
        <?php settings_fields('saz_tags_plugin_options'); ?>
        <?php do_settings_sections('saz-tags-plugin'); ?>
        <?php submit_button(); ?>
    </form>
</div>
