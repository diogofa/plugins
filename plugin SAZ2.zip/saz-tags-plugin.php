<?php
/*
Plugin Name: SAZ Tags Plugin
Description: Adiciona as tags do SAZ dentro da tag </head>.
Version: 2.0
Author: Diogo Alves
Author URI: https://zplug.com.br
*/

// Função para adicionar as tags do SAZ no cabeçalho
function add_saz_tags() {
    // Obtém as tags do SAZ do banco de dados
    $saz_tags = get_option('saz_tags');

    echo $saz_tags;
}

// Hook para adicionar as tags do SAZ no cabeçalho
add_action('wp_head', 'add_saz_tags');

// Função para adicionar a página de configurações do plugin
function saz_tags_plugin_settings_page() {
    // Verifica se o usuário possui permissão para acessar a página de configurações
    if (!current_user_can('manage_options')) {
        return;
    }

    // Renderiza o formulário de configurações
    ?>
    <div class="wrap">
        <h1>SAZ Tags Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('saz_tags_plugin_options'); ?>
            <?php do_settings_sections('saz-tags-plugin'); ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Função de callback para o campo de texto
function saz_tags_plugin_field_callback() {
    $saz_tags = get_option('saz_tags');
    echo '<textarea name="saz_tags" rows="6" cols="50">' . esc_textarea($saz_tags) . '</textarea>';
}

// Função para registrar as configurações do plugin
add_action('admin_init', 'saz_tags_plugin_register_settings');
function saz_tags_plugin_register_settings() {
    // Registra a opção de configurações das tags do SAZ
    register_setting('saz_tags_plugin_options', 'saz_tags');
    
    // Adiciona a seção de configurações das tags do SAZ
    add_settings_section(
        'saz_tags_plugin_section',
        'SAZ Tags Configuration',
        'saz_tags_plugin_section_callback',
        'saz-tags-plugin'
    );
    
    // Adiciona o campo de texto para editar as tags do SAZ
    add_settings_field(
        'saz_tags',
        'SAZ Tags',
        'saz_tags_plugin_field_callback',
        'saz-tags-plugin',
        'saz_tags_plugin_section'
    );
}

// Função de callback para a seção de configurações
function saz_tags_plugin_section_callback() {
    echo '<p>Confira o manual de instalação em <a href="https://analise.zplug.com.br/help/install">Ajuda</a>.</p>';
    echo '<p>Insira sua tag SAZ abaixo:</p>';
}

// Função para adicionar o menu de configurações do plugin
add_action('admin_menu', 'saz_tags_plugin_add_settings_menu');
function saz_tags_plugin_add_settings_menu() {
    // Adiciona a página de configurações no menu
    add_options_page(
        'SAZ Tags Plugin Settings',
        'SAZ Tags Plugin',
        'manage_options',
        'saz-tags-plugin',
        'saz_tags_plugin_settings_page'
    );
}
