<?php
/*
Plugin Name: Calculadora de Economia com Energia Solar
Description: Um plugin para criar uma calculadora de economia com energia solar.
Version: 4.0
Author: ZPLUG
Author URI: http://www.zplug.com.br
*/

// Adiciona um menu de configuração do plugin no painel administrativo
function ces_admin_menu() {
    add_options_page('Configurações da Calculadora de Energia Solar', 'Calculadora de Energia Solar', 'manage_options', 'ces-settings', 'ces_render_settings_page');
}
add_action('admin_menu', 'ces_admin_menu');

// Renderiza a página de configurações do plugin
function ces_render_settings_page() {
    // Verifica se o usuário tem permissão para acessar as configurações do plugin
    if (!current_user_can('manage_options')) {
        return;
    }

    // Salva as configurações quando o formulário for enviado
    if (isset($_POST['ces_save_settings'])) {
        $percentage = isset($_POST['ces_percentage']) ? intval($_POST['ces_percentage']) : 0;
        $kwh_value = isset($_POST['ces_kwh_value']) ? floatval($_POST['ces_kwh_value']) : 0;
        $show_consumption = isset($_POST['ces_show_consumption']) ? true : false;
        $show_payment = isset($_POST['ces_show_payment']) ? true : false;
        update_option('ces_percentage', $percentage);
        update_option('ces_kwh_value', $kwh_value);
        update_option('ces_show_consumption', $show_consumption);
        update_option('ces_show_payment', $show_payment);
        echo '<div class="notice notice-success"><p>Configurações salvas com sucesso!</p></div>';
    }

    // Obtém as configurações atuais
    $current_percentage = get_option('ces_percentage', 50);
    $current_kwh_value = get_option('ces_kwh_value', 0.25); // Valor padrão: 0.25
    $show_consumption = get_option('ces_show_consumption', true);
    $show_payment = get_option('ces_show_payment', true);

    // Renderiza o formulário de configurações
    ?>
    <div class="wrap">
        <h1>Configurações da Calculadora de Energia Solar</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">Porcentagem de Economia:</th>
                    <td>
                        <input type="number" name="ces_percentage" value="<?php echo $current_percentage; ?>" min="0" max="100" class="regular-text">
                        <p class="description">Digite a porcentagem de economia para exibir na calculadora.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Valor Médio de kWh:</th>
                    <td>
                        <input type="number" name="ces_kwh_value" value="<?php echo $current_kwh_value; ?>" min="0" step="0.01" class="regular-text">
                        <p class="description">Digite o valor médio de kWh para calcular o consumo.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Exibir Consumo de kWh:</th>
                    <td>
                        <label><input type="checkbox" name="ces_show_consumption" <?php echo $show_consumption ? 'checked' : ''; ?>> Sim</label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Exibir Valor de energia a pagar:</th>
                    <td>
                        <label><input type="checkbox" name="ces_show_payment" <?php echo $show_payment ? 'checked' : ''; ?>> Sim</label>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="ces_save_settings" class="button-primary" value="Salvar Configurações">
            </p>
        </form>

        <h2>Como usar a Calculadora de Economia com Energia Solar</h2>
        <p>Para adicionar a calculadora em uma página ou post, use o seguinte shortcode:</p>
        <pre><code>[ces_calculator]</code></pre>
    </div>
    <?php
}

// Função para renderizar o shortcode da calculadora
function ces_render_calculator_shortcode($atts) {
    // Obtém as configurações
    $percentage = get_option('ces_percentage', 95);
    $kwh_value = get_option('ces_kwh_value', 0.55); // Valor padrão: 0.25
    $show_consumption = get_option('ces_show_consumption', true);
    $show_payment = get_option('ces_show_payment', true);

    // Renderiza o código HTML da calculadora
    $html = '<div class="ces-calculator">';
    $html .= '<h2>Calculadora de Economia com Energia Solar</h2>';
    $html .= '<div class="ces-inputs">';
    $html .= '<label for="ces-monthly-bill">Valor mensal da conta de energia:</label>';
    $html .= '<input type="number" id="ces-monthly-bill" class="ces-input" min="0" step="0.01" placeholder="R$">';
    $html .= '<button id="ces-calculate-btn" class="ces-btn">Calcular</button>';
    $html .= '</div>';
    $html .= '<div class="ces-results" style="display: none;">';
    if ($show_consumption) {
        $html .= '<div class="ces-result-item"><span class="ces-result-label">Consumo de kWh:</span><span id="ces-consumption" class="ces-result-value"></span></div>';
    }
    $html .= '<div class="ces-result-item"><span class="ces-result-label">Economia mensal com energia solar:</span><span id="ces-savings" class="ces-result-value"></span></div>';
    if ($show_payment) {
        $html .= '<div class="ces-result-item"><span class="ces-result-label">Valor de energia a pagar:</span><span id="ces-payment" class="ces-result-value"></span></div>';
    }
    $html .= '</div>';
    $html .= '</div>';

    // Inclui o CSS personalizado para a calculadora
    $html .= '<style>
                .ces-calculator {
                    padding: 20px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    background-color: #f9f9f9;
                }
                
                .ces-calculator h2 {
                    margin-top: 0;
                }
                
                .ces-inputs {
                    display: flex;
                    align-items: center;
                    margin-bottom: 10px;
                }
                
                .ces-inputs label {
                    margin-right: 10px;
                }
                
                .ces-inputs input {
                    width: 150px;
                    padding: 5px;
                    border: 1px solid #ccc;
                    border-radius: 3px;
                }
                
                .ces-inputs button {
                    padding: 5px 10px;
                    background-color: #007bff;
                    color: #fff;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }
                
                .ces-results {
                    display: flex;
                    flex-direction: column;
                }
                
                .ces-result-item {
                    margin-bottom: 10px;
                }
                
                .ces-result-label {
                    font-weight: bold;
                    margin-right: 10px;
                }
                
                .ces-result-value {
                    font-weight: bold;
                    color: #007bff;
                }
            </style>';

    // Inclui o script JavaScript para o cálculo da economia
    $html .= '<script>
                document.addEventListener("DOMContentLoaded", function() {
                    var calculateBtn = document.getElementById("ces-calculate-btn");
                    var monthlyBillInput = document.getElementById("ces-monthly-bill");
                    var consumptionSpan = document.getElementById("ces-consumption");
                    var savingsSpan = document.getElementById("ces-savings");
                    var paymentSpan = document.getElementById("ces-payment");
                    var resultsDiv = document.querySelector(".ces-results");

                    calculateBtn.addEventListener("click", function() {
                        var monthlyBill = parseFloat(monthlyBillInput.value);

                        if (isNaN(monthlyBill) || monthlyBill < 0) {
                            consumptionSpan.textContent = "";
                            savingsSpan.textContent = "";
                            paymentSpan.textContent = "";
                            resultsDiv.style.display = "none";
                            return;
                        }

                        var consumption = monthlyBill / ' . $kwh_value . ';
                        var savings = monthlyBill * (' . $percentage . ' / 100);
                        var payment = monthlyBill - savings;

                        if (' . ($show_consumption ? 'true' : 'false') . ') {
                            consumptionSpan.textContent = "Consumo de kWh: " + consumption.toFixed(2);
                        } else {
                            consumptionSpan.textContent = "";
                        }

                        savingsSpan.textContent = "Economia mensal com energia solar: R$ " + savings.toFixed(2);

                        if (' . ($show_payment ? 'true' : 'false') . ') {
                            paymentSpan.textContent = "Valor de energia a pagar: R$ " + payment.toFixed(2);
                        } else {
                            paymentSpan.textContent = "";
                        }

                        resultsDiv.style.display = "block";
                    });
                });
            </script>';

    return $html;
}
add_shortcode('ces_calculator', 'ces_render_calculator_shortcode');
