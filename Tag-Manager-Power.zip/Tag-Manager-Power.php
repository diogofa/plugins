<?php
/*
Plugin Name: Plugin TAG's Manager Power
Plugin URI: https://zplug.com.br/meu-plugin-tags
Description: Plugin para adicionar tags do Google Analytics, Facebook Pixel, SAZ Pixel e tags personalizadas.
Version: 1.0
Author: ZPLUG
Author URI: https://zplug.com.br
*/

// Função para exibir as opções do plugin na área administrativa
function meu_plugin_tags_admin_page() {
  // Verifique se o usuário tem permissão para acessar as configurações do plugin
  if (!current_user_can('manage_options')) {
    return;
  }

  // Verifique se o formulário foi enviado e atualize as opções do plugin
  if (isset($_POST['submit'])) {
    update_option('google_analytics_tag', $_POST['google_analytics_tag']);
    update_option('facebook_pixel_tag', $_POST['facebook_pixel_tag']);
    update_option('saz_pixel_tag', $_POST['saz_pixel_tag']);
    update_option('tag_personalizada', $_POST['tag_personalizada']);
    ?>
    <div class="notice notice-success is-dismissible">
      <p><?php esc_html_e('Tags atualizadas com sucesso!', 'meu-plugin-tags'); ?></p>
    </div>
    <?php
  }

  // Recupere as tags armazenadas nas opções do plugin
  $google_analytics_tag = get_option('google_analytics_tag', '');
  $facebook_pixel_tag = get_option('facebook_pixel_tag', '');
  $saz_pixel_tag = get_option('saz_pixel_tag', '');
  $tag_personalizada = get_option('tag_personalizada', '');
  ?>

  <div class="wrap">
    <h1><?php esc_html_e('Configurações de Tags', 'meu-plugin-tags'); ?></h1>
    <form method="post" action="">
      <table class="form-table">
        <tr>
          <th scope="row"><?php esc_html_e('Tag do Google Analytics', 'meu-plugin-tags'); ?></th>
          <td>
            <textarea name="google_analytics_tag" rows="4" cols="50"><?php echo esc_textarea($google_analytics_tag); ?></textarea>
            <p class="description"><?php esc_html_e('Insira o código da tag do Google Analytics aqui.', 'meu-plugin-tags'); ?></p>
          </td>
        </tr>
        <tr>
          <th scope="row"><?php esc_html_e('Tag do Facebook Pixel', 'meu-plugin-tags'); ?></th>
          <td>
            <textarea name="facebook_pixel_tag" rows="4" cols="50"><?php echo esc_textarea($facebook_pixel_tag); ?></textarea>
            <p class="description"><?php esc_html_e('Insira o código da tag do Facebook Pixel aqui.', 'meu-plugin-tags'); ?></p>
          </td>
        </tr>
        <tr>
          <th scope="row"><?php esc_html_e('Tag do SAZ Pixel', 'meu-plugin-tags'); ?></th>
          <td>
            <textarea name="saz_pixel_tag" rows="4" cols="50"><?php echo esc_textarea($saz_pixel_tag); ?></textarea>
            <p class="description"><?php esc_html_e('Insira o código da tag do SAZ Pixel aqui.', 'meu-plugin-tags'); ?></p>
          </td>
        </tr>
        <tr>
          <th scope="row"><?php esc_html_e('Tag Personalizada', 'meu-plugin-tags'); ?></th>
          <td>
            <textarea name="tag_personalizada" rows="4" cols="50"><?php echo esc_textarea($tag_personalizada); ?></textarea>
            <p class="description"><?php esc_html_e('Insira o código da tag personalizada aqui.', 'meu-plugin-tags'); ?></p>
          </td>
        </tr>
      </table>
      <p class="submit">
        <input type="submit" name="submit" class="button-primary" value="<?php esc_attr_e('Salvar Tags', 'meu-plugin-tags'); ?>" />
      </p>
    </form>
  </div>
  <?php
}

// Adicione a página de configurações do plugin ao menu do WordPress
function meu_plugin_tags_admin_menu() {
  add_menu_page(
    'Plugin TAG\'s Manager Power',
    'Plugin TAG\'s',
    'manage_options',
    'meu-plugin-tags',
    'meu_plugin_tags_admin_page',
    'dashicons-tag',
    2
  );
}
add_action('admin_menu', 'meu_plugin_tags_admin_menu');

// Função para adicionar as tags ao cabeçalho do site
function adicionar_tags() {
  // Recupere as tags armazenadas nas opções do plugin
  $google_analytics_tag = get_option('google_analytics_tag', '');
  $facebook_pixel_tag = get_option('facebook_pixel_tag', '');
  $saz_pixel_tag = get_option('saz_pixel_tag', '');
  $tag_personalizada = get_option('tag_personalizada', '');

  // Adicione as tags ao cabeçalho do site
  echo $google_analytics_tag;
  echo $facebook_pixel_tag;
  echo $saz_pixel_tag;
  echo $tag_personalizada;
}
add_action('wp_head', 'adicionar_tags');
