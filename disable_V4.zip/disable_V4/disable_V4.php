<?php
/**
 * Plugin Name: Disable Updates and Notifications
 * Description: Desativa as atualizações e caixas de notificações dos outros plugins.
 * Version: 1.0
 * Author: ZPLUG
 */

// Impede atualizações automáticas de plugins
function disable_plugin_updates( $value ) {
    if ( is_object( $value ) && isset( $value->response ) ) {
        $value->response = array();
    }
    return $value;
}
add_filter( 'site_transient_update_plugins', 'disable_plugin_updates' );

// Remove as caixas de notificações
function disable_admin_notifications() {
    global $wp_filter;

    // Remove todas as ações relacionadas a notificações
    if ( isset( $wp_filter['admin_notices'] ) ) {
        unset( $wp_filter['admin_notices'] );
    }
}
add_action( 'admin_init', 'disable_admin_notifications' );
