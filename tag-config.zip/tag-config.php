<?php
/**
 * Plugin Name: TAG Config
 * Plugin URI: https://plugin.zplug.com.br
 * Description: Adiciona a tag do Google, a tag do Facebook e tags personalizadas.
 * Version: 1.0
 * Author: ZPLUG
 * Author URI: https://www.zplug.com.br
 */

// Função para adicionar as tags do Google, do Facebook e as tags personalizadas
function adicionar_tags_scripts() {
  // Tag do Google
  $tag_google = get_option('meu_plugin_tag_google');
  if (!empty($tag_google)) {
    echo '<!-- Adicione aqui a tag do Google -->' . esc_html($tag_google);
  }

  // Tag do Facebook
  $tag_facebook = get_option('meu_plugin_tag_facebook');
  if (!empty($tag_facebook)) {
    echo '<!-- Adicione aqui a tag do Facebook -->' . esc_html($tag_facebook);
  }

  // Tags personalizadas
  $tags_personalizadas = get_option('meu_plugin_tags_personalizadas');
  if (!empty($tags_personalizadas)) {
    echo '<!-- Adicione aqui as tags personalizadas -->' . esc_html($tags_personalizadas);
  }
}

// Hook para adicionar as tags aos hooks apropriados
add_action('wp_head', 'adicionar_tags_scripts');

// Função para exibir a página de configurações do plugin
function meu_plugin_pagina_configuracoes() {
  // Verifica se o usuário atual tem permissão para acessar a página de configurações
  if (!current_user_can('manage_options')) {
    return;
  }

  // Exibe o conteúdo da página de configurações
  ?>
  <div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <form method="post" action="options.php">
      <?php
      // Adiciona as configurações do plugin ao formulário
      settings_fields('meu_plugin_opcoes');
      do_settings_sections('meu_plugin');
      submit_button();
      ?>
    </form>
  </div>
  <?php
}

// Hook para adicionar a página de configurações ao menu do painel de administração
add_action('admin_menu', 'meu_plugin_adicionar_pagina_configuracoes');
function meu_plugin_adicionar_pagina_configuracoes() {
  add_options_page(
    'Configurações do Meu Plugin',
    'TAG Config',
    'manage_options',
    'meu_plugin',
    'meu_plugin_pagina_configuracoes'
  );
}

// Função para registrar as configurações do plugin
add_action('admin_init', 'meu_plugin_registrar_opcoes');
function meu_plugin_registrar_opcoes() {
  // Registrar as configurações do plugin
  register_setting(
    'meu_plugin_opcoes',
    'meu_plugin_tag_google',
    array('sanitize_callback' => 'sanitize_textarea_field')
  );
  register_setting(
    'meu_plugin_opcoes',
    'meu_plugin_tag_facebook',
    array('sanitize_callback' => 'sanitize_textarea_field')
  );
  register_setting(
    'meu_plugin_opcoes',
    'meu_plugin_tags_personalizadas',
    array('sanitize_callback' => 'sanitize_textarea_field')
  );

  // Adicionar a seção de tags personalizadas
  add_settings_section(
    'meu_plugin_secao_tags',
    'Tags Personalizadas',
    'meu_plugin_secao_tags_callback',
    'meu_plugin'
  );

  // Adicionar os campos de entrada para as tags personalizadas
  add_settings_field(
    'meu_plugin_tag_google_field',
    'Tag do Google',
    'meu_plugin_tag_google_field_callback',
    'meu_plugin',
    'meu_plugin_secao_tags'
  );
  add_settings_field(
    'meu_plugin_tag_facebook_field',
    'Tag do Facebook',
    'meu_plugin_tag_facebook_field_callback',
    'meu_plugin',
    'meu_plugin_secao_tags'
  );
  add_settings_field(
    'meu_plugin_tags_personalizadas_field',
    'Tags Personalizadas',
    'meu_plugin_tags_personalizadas_field_callback',
    'meu_plugin',
    'meu_plugin_secao_tags'
  );
}

// Função de callback para a seção de tags personalizadas
function meu_plugin_secao_tags_callback() {
  echo '<p>Insira as tags abaixo:</p>';
}

// Função de callback para o campo de entrada da tag do Google
function meu_plugin_tag_google_field_callback() {
  $tag_google = get_option('meu_plugin_tag_google');
  $tag_google = !empty($tag_google) ? $tag_google : '';

  echo '<textarea name="meu_plugin_tag_google" rows="5" cols="50">' . esc_textarea($tag_google) . '</textarea>';
}

// Função de callback para o campo de entrada da tag do Facebook
function meu_plugin_tag_facebook_field_callback() {
  $tag_facebook = get_option('meu_plugin_tag_facebook');
  $tag_facebook = !empty($tag_facebook) ? $tag_facebook : '';

  echo '<textarea name="meu_plugin_tag_facebook" rows="5" cols="50">' . esc_textarea($tag_facebook) . '</textarea>';
}

// Função de callback para o campo de entrada das tags personalizadas
function meu_plugin_tags_personalizadas_field_callback() {
  $tags_personalizadas = get_option('meu_plugin_tags_personalizadas');
  $tags_personalizadas = !empty($tags_personalizadas) ? $tags_personalizadas : '';

  echo '<textarea name="meu_plugin_tags_personalizadas" rows="5" cols="50">' . esc_textarea($tags_personalizadas) . '</textarea>';
}
